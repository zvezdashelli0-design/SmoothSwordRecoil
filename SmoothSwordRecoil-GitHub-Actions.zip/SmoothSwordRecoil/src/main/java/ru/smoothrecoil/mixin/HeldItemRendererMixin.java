package ru.smoothrecoil.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    private static final ThreadLocal<Boolean> smoothSwordRecoil$isSword =
            ThreadLocal.withInitial(() -> false);

    @Inject(
        method = "renderFirstPersonItem",
        at = @At("HEAD")
    )
    private void smoothSwordRecoil$begin(
            AbstractClientPlayerEntity player,
            float tickProgress,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack stack,
            float equipProgress,
            MatrixStack matrices,
            OrderedRenderCommandQueue queue,
            int light,
            CallbackInfo ci
    ) {
        smoothSwordRecoil$isSword.set(isSword(stack));
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void smoothSwordRecoil$end(
            AbstractClientPlayerEntity player,
            float tickProgress,
            float pitch,
            Hand hand,
            float swingProgress,
            ItemStack stack,
            float equipProgress,
            MatrixStack matrices,
            OrderedRenderCommandQueue queue,
            int light,
            CallbackInfo ci
    ) {
        smoothSwordRecoil$isSword.remove();
    }

    @ModifyVariable(
        method = "renderFirstPersonItem",
        at = @At("HEAD"),
        argsOnly = true,
        ordinal = 2
    )
    private float smoothSwordRecoil$smoothSwing(float vanillaProgress) {
        if (!smoothSwordRecoil$isSword.get() || vanillaProgress <= 0.0f) {
            return vanillaProgress;
        }

        // Ease-in/ease-out curve: preserves the swing interval while softening
        // the start and the return to the resting pose.
        float t = Math.max(0.0f, Math.min(1.0f, vanillaProgress));
        float smooth = t * t * (3.0f - 2.0f * t);

        // Blend with vanilla so the animation remains recognizable.
        return vanillaProgress * 0.28f + smooth * 0.72f;
    }

    private static boolean isSword(ItemStack stack) {
        return stack.isOf(Items.WOODEN_SWORD)
            || stack.isOf(Items.STONE_SWORD)
            || stack.isOf(Items.IRON_SWORD)
            || stack.isOf(Items.GOLDEN_SWORD)
            || stack.isOf(Items.DIAMOND_SWORD)
            || stack.isOf(Items.NETHERITE_SWORD);
    }
}
