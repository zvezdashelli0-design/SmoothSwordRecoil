package ru.smoothrecoil;

import net.fabricmc.api.ClientModInitializer;

public final class SmoothSwordRecoilClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Client-only animation mod.
    }
}
